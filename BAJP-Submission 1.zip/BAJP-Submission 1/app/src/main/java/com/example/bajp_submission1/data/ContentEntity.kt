package com.example.bajp_submission1.data

data class ContentEntity(
    var id: String,
    var title: String,
    var genre: String,
    var description: String,
    var date: String,
    var score: String,
    var imagePath: String
)
